tinyMCE.addI18n('fr.template_dlg',{
title:"Mod\u00E8les",
label:"Mod\u00E8le",
desc_label:"Description",
desc:"Ins\u00E9rer un mod\u00E8le pr\u00E9d\u00E9fini",
select:"Choisir un mod\u00E8le",
preview:"Pr\u00E9visualiser",
warning:"Attention : Changer un mod\u00E8le pour un autre peut entra\u00EEner une perte de donn\u00E9es !",
mdate_format:"%d-%m-%Y %H:%M:%S",
cdate_format:"%d-%m-%Y %H:%M:%S",
months_long:"Janvier,F\u00E9vrier,Mars,Avril,Mai,Juin,Juillet,Ao\u00FBt,Septembre,Octobre,Novembre,D\u00E9cembre",
months_short:"Jan,F\u00E9v,Mar,Avr,Mai,Juin,Juil,Ao\u00FBt,Sep,Oct,Nov,D\u00E9c",
day_long:"Dimanche,Lundi,Mardi,Mercredi,Jeudi,Vendredi,Samedi,Dimanche",
day_short:"Dim,Lun,Mar,Mer,Jeu,Ven,Sam,Dim"
});